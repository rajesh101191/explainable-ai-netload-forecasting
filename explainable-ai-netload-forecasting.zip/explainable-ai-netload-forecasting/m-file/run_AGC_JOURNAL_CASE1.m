function run_AGC_JOURNAL_CASE1()
% ==============================================================
% JOURNAL-GRADE AGC/LFC STUDY (MATLAB R2016a, single .m file)
% CASE-I: Two-area reheat thermal power system
% Optimizers: ALA vs PSO vs GA
% Adds: baseline PI, robustness tests, inertia-proxy study, metrics table
% ==============================================================

clc; close all;

%% -------------------- CASE-I PARAMETERS -----------------------
P = struct();
P.f0  = 50;         % Hz
P.Tg  = 0.07;       % governor time constant (s)
P.Tt  = 0.35;       % turbine time constant (s)
P.Tr  = 9;          % reheat time constant (s)
P.Kr  = 0.55;       % reheat gain
P.Kp  = 1;          % normalized (kept stable; use 125 only if model scaled)
P.Tp  = 18;         % power system time constant (s)
P.R   = 2.6;        % droop
P.B1  = 0.400;      % bias area-1
P.B2  = 0.400;      % bias area-2
P.T12 = 0.5501/(2*pi); % synchronizing coefficient (T12)
P.DPL1 = 0.015;     % load disturbance in area-1 (pu)

%% -------------------- SIMULATION CONFIG -----------------------
cfg = struct();
cfg.Tsim = 100;        % seconds
cfg.t0_dist = 1;       % disturbance time
cfg.DPL2 = 0;          % area-2 step (default 0)
cfg.w1 = 1; cfg.w2 = 1; cfg.w3 = 0.5;  % weights in objective
cfg.df_limit = 0.2;     % penalty threshold (Hz)
cfg.rhoFreq = 200;      % penalty strength
cfg.settleBand = 0.002; % settling band in Hz (2 mHz)

%% -------------------- OPTIMIZATION BOUNDS ---------------------
% Force integral action for realistic AGC
lb = [0 0.01 0 0.01];
ub = [5 5 5 5];
lb = lb(:)'; ub = ub(:)';

fitness = @(x) fitness_Journal(x, P, cfg);

%% -------------------- OPTIMIZER SETTINGS ----------------------
ala.nPop  = 30;  ala.maxIt = 50;
pso.nPop  = 30;  pso.maxIt = 50; pso.w=0.7; pso.c1=1.7; pso.c2=1.7;
ga.nPop   = 30;  ga.maxIt  = 50; ga.pc=0.8; ga.pm=0.2; ga.mutSigma=0.15;

%% ======================== BASELINE ============================
baselinePI = [1.0 0.2  1.0 0.2];

%% ======================== RUN OPTIMIZERS ======================
disp('Running ALA...');
[bestALA, fALA, histALA] = ALA_optimize(fitness, lb, ub, ala);

disp('Running PSO...');
[bestPSO, fPSO, histPSO] = PSO_optimize(fitness, lb, ub, pso);

disp('Running GA...');
[bestGA,  fGA,  histGA ] = GA_optimize(fitness, lb, ub, ga);

%% -------------------- SUMMARY PRINT ---------------------------
fprintf('\n==== OPTIMAL GAINS (CASE-I) ====\n');
fprintf('BASE: J=%.4f  [%f %f %f %f]\n', fitness(baselinePI), baselinePI);
fprintf('ALA : J=%.4f  [%f %f %f %f]\n', fALA, bestALA);
fprintf('PSO : J=%.4f  [%f %f %f %f]\n', fPSO, bestPSO);
fprintf('GA  : J=%.4f  [%f %f %f %f]\n', fGA, bestGA);

%% -------------------- CONVERGENCE PLOT ------------------------
figure; hold on;
plot(histALA,'LineWidth',1.5);
plot(histPSO,'LineWidth',1.5);
plot(histGA ,'LineWidth',1.5);
grid on; xlabel('Iteration'); ylabel('Best Fitness (J)');
title('Convergence Comparison (Journal Fitness)');
legend('ALA','PSO','GA');

%% -------------------- METRICS TABLES --------------------------
print_results_table('BASELINE', baselinePI, P, cfg);
print_results_table('ALA', bestALA, P, cfg);
print_results_table('PSO', bestPSO, P, cfg);
print_results_table('GA',  bestGA,  P, cfg);

%% -------------------- RESPONSE PLOTS ---------------------------
plotResponse(baselinePI, P, cfg, 'Baseline PI');
plotResponse(bestALA,    P, cfg, 'ALA');
plotResponse(bestPSO,    P, cfg, 'PSO');
plotResponse(bestGA,     P, cfg, 'GA');

%% -------------------- ROBUSTNESS SUITE ------------------------
run_robustness_suite(baselinePI, bestALA, bestPSO, bestGA, P, cfg);

%% -------------------- INERTIA PROXY STUDY ---------------------
inertia_proxy_study(bestPSO, P, cfg, 'PSO');
inertia_proxy_study(bestGA,  P, cfg, 'GA');

disp('All journal-grade tests completed successfully.');
end

% ==============================================================
%                    JOURNAL FITNESS FUNCTION
% ==============================================================

function J = fitness_Journal(x,P,cfg)
[t,y] = simulate_system(x,P,cfg);

df1  = y(:,4);  df2  = y(:,8);  ptie = y(:,9);

ITAE = trapz(t, t.*(abs(df1)+abs(df2)+cfg.w3*abs(ptie)));
IAE  = trapz(t, (abs(df1)+abs(df2)+cfg.w3*abs(ptie)));
ISE  = trapz(t, (df1.^2 + df2.^2 + cfg.w3*ptie.^2));

% Frequency violation penalty
penFreq = 0;
mx = max([max(abs(df1)) max(abs(df2))]);
if mx > cfg.df_limit
    penFreq = cfg.rhoFreq*(mx/cfg.df_limit);
end

% Gain size penalty
gamma = 0.25;
gainPenalty = gamma*sum(x.^2);

% Boundary penalty discourages hitting exact bounds
bndPenalty = 0;
epsB = 1e-3;
for k=1:numel(x)
    if abs(x(k)-0) < epsB || abs(x(k)-5) < epsB
        bndPenalty = bndPenalty + 30;
    end
end

alpha = 0.2;  beta = 0.1;
J = ITAE + alpha*IAE + beta*ISE + gainPenalty + bndPenalty + penFreq;

if ~isfinite(J), J = 1e9; end
end

% ==============================================================
%                      SYSTEM SIMULATION
% ==============================================================

function [t,y] = simulate_system(g,P,cfg)
x0 = zeros(11,1);
opts = odeset('RelTol',1e-6,'AbsTol',1e-8,'MaxStep',0.05);
[t,y] = ode45(@(t,x)odefun(t,x,g,P,cfg), [0 cfg.Tsim], x0, opts);
end

function dx = odefun(t,x,g,P,cfg)
xg1=x(1); xr1=x(2); xt1=x(3); df1=x(4);
xg2=x(5); xr2=x(6); xt2=x(7); df2=x(8);
pt =x(9); I1 =x(10); I2 =x(11);

Kp1=g(1); Ki1=g(2); Kp2=g(3); Ki2=g(4);

dPL1 = (t>=cfg.t0_dist)*P.DPL1;
dPL2 = (t>=cfg.t0_dist)*cfg.DPL2;

ACE1 = P.B1*df1 + pt;
ACE2 = P.B2*df2 - pt;

u1 = -Kp1*ACE1 - Ki1*I1;
u2 = -Kp2*ACE2 - Ki2*I2;

dxg1 = (-xg1 + (u1 - df1/P.R))/P.Tg;
dxg2 = (-xg2 + (u2 - df2/P.R))/P.Tg;

dxr1 = (-xr1 + xg1)/P.Tr;
dxr2 = (-xr2 + xg2)/P.Tr;

pm1 = (1-P.Kr)*xg1 + P.Kr*xr1;
pm2 = (1-P.Kr)*xg2 + P.Kr*xr2;

dxt1 = (-xt1 + pm1)/P.Tt;
dxt2 = (-xt2 + pm2)/P.Tt;

dpt  = (2*pi*P.T12)*(df1 - df2);

ddf1 = (-df1 + P.Kp*(xt1 - dPL1 - pt))/P.Tp;
ddf2 = (-df2 + P.Kp*(xt2 - dPL2 + pt))/P.Tp;

dx = [dxg1;dxr1;dxt1;ddf1;
      dxg2;dxr2;dxt2;ddf2;
      dpt; ACE1; ACE2];
end

% ==============================================================
%                      METRICS & TABLES
% ==============================================================

function M = compute_metrics(t,y,bandHz,cfg)
df1  = y(:,4); df2  = y(:,8); ptie = y(:,9);

M.peak_df1  = max(abs(df1));
M.peak_df2  = max(abs(df2));
M.peak_ptie = max(abs(ptie));

M.ts_df1 = settling_time(t,df1,bandHz);
M.ts_df2 = settling_time(t,df2,bandHz);

M.ITAE = trapz(t, t.*(abs(df1)+abs(df2)+cfg.w3*abs(ptie)));
M.IAE  = trapz(t, (abs(df1)+abs(df2)+cfg.w3*abs(ptie)));
M.ISE  = trapz(t, (df1.^2 + df2.^2 + cfg.w3*ptie.^2));
end

function ts = settling_time(t,x,band)
idx = find(abs(x) > band);
if isempty(idx), ts = 0; else ts = t(idx(end)); end
end

function print_results_table(tag, gains, P, cfg)
[t,y] = simulate_system(gains,P,cfg);
M = compute_metrics(t,y,cfg.settleBand,cfg);
J = fitness_Journal(gains,P,cfg);

fprintf('\n---- %s (Case-I) ----\n', tag);
fprintf('J = %.4f\n', J);
fprintf('Gains [Kp1 Ki1 Kp2 Ki2] = [%.4f %.4f %.4f %.4f]\n', gains);
fprintf('Peak |df1| = %.6f Hz | Peak |df2| = %.6f Hz\n', M.peak_df1, M.peak_df2);
fprintf('Ts(df1) = %.2f s | Ts(df2) = %.2f s  (band=%.4f Hz)\n', M.ts_df1, M.ts_df2, cfg.settleBand);
fprintf('Peak |Ptie| = %.6f pu\n', M.peak_ptie);
fprintf('ITAE=%.4f | IAE=%.4f | ISE=%.4f\n', M.ITAE, M.IAE, M.ISE);
end

% ==============================================================
%                        PLOTS
% ==============================================================

function plotResponse(g,P,cfg,name)
[t,y] = simulate_system(g,P,cfg);
df1 = y(:,4); df2 = y(:,8); ptie = y(:,9);

figure;
plot(t,df1,'b',t,df2,'r','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta f (Hz)');
title(['Frequency Response - ' name]);
legend('Area 1','Area 2');

figure;
plot(t,ptie,'k','LineWidth',1.2);
grid on; xlabel('Time (s)'); ylabel('\Delta P_{tie} (pu)');
title(['Tie-line Power - ' name]);
end

% ==============================================================
%                     ROBUSTNESS SUITE
% ==============================================================

function run_robustness_suite(base,ala,pso,ga,P,cfg)
PL_list = [0.01 0.015 0.02];

fprintf('\n================ ROBUSTNESS: Area-1 load steps ================\n');
for k=1:numel(PL_list)
    P2 = P; P2.DPL1 = PL_list(k);
    cfg2 = cfg; cfg2.DPL2 = 0;
    fprintf('\n### Scenario: DPL1 = %.3f pu, DPL2 = 0 ###\n', P2.DPL1);
    print_results_table('BASE', base, P2, cfg2);
    print_results_table('ALA',  ala,  P2, cfg2);
    print_results_table('PSO',  pso,  P2, cfg2);
    print_results_table('GA',   ga,   P2, cfg2);
end

fprintf('\n================ ROBUSTNESS: Area-2 load step ================\n');
P2 = P; P2.DPL1 = 0.015;
cfg2 = cfg; cfg2.DPL2 = 0.015;
fprintf('\n### Scenario: DPL1 = %.3f pu, DPL2 = %.3f pu ###\n', P2.DPL1, cfg2.DPL2);
print_results_table('BASE', base, P2, cfg2);
print_results_table('ALA',  ala,  P2, cfg2);
print_results_table('PSO',  pso,  P2, cfg2);
print_results_table('GA',   ga,   P2, cfg2);
end

% ==============================================================
%                   INERTIA PROXY STUDY
% ==============================================================

function inertia_proxy_study(bestController,P,cfg,tag)
Tp_list = [18 10 6];
fprintf('\n================ INERTIA PROXY STUDY (%s) ================\n', tag);
for i=1:numel(Tp_list)
    P2 = P; P2.Tp = Tp_list(i);
    cfg2 = cfg; cfg2.DPL2 = 0;
    fprintf('\n--- Proxy inertia via Tp = %.1f s ---\n', P2.Tp);
    print_results_table(tag, bestController, P2, cfg2);
end
end

% ==============================================================
%                        ALA OPTIMIZER
% ==============================================================

function [bestX,bestF,hist] = ALA_optimize(f,lb,ub,ala)
lb=lb(:)'; ub=ub(:)';
nVar=numel(lb); nPop=ala.nPop; maxIt=ala.maxIt;

X = rand(nPop,nVar).*repmat(ub-lb,nPop,1) + repmat(lb,nPop,1);
F = zeros(nPop,1);
for i=1:nPop, F(i)=f(X(i,:)); end

[bestF,idx]=min(F); bestX=X(idx,:);
hist=zeros(maxIt,1);

for it=1:maxIt
    E=2*(1-it/maxIt);
    for i=1:nPop
        if rand<0.5
            Xn = X(i,:) + E*randn(1,nVar).*0.08.*(ub-lb);
        else
            Xn = X(i,:) + (1-E)*(bestX - X(i,:)).*rand(1,nVar);
        end
        Xn=min(max(Xn,lb),ub);
        Fn=f(Xn);
        if Fn<F(i)
            X(i,:)=Xn; F(i)=Fn;
            if Fn<bestF, bestF=Fn; bestX=Xn; end
        end
    end
    hist(it)=bestF;
end
end

% ==============================================================
%                        PSO OPTIMIZER
% ==============================================================

function [gBest,gBestF,hist] = PSO_optimize(f,lb,ub,p)
lb=lb(:)'; ub=ub(:)';
nVar=numel(lb); nPop=p.nPop; maxIt=p.maxIt;

X = rand(nPop,nVar).*repmat(ub-lb,nPop,1) + repmat(lb,nPop,1);
V = zeros(nPop,nVar);

pBest = X;
pBestF = zeros(nPop,1);
for i=1:nPop, pBestF(i)=f(X(i,:)); end

[gBestF,idx]=min(pBestF); gBest=pBest(idx,:);
hist=zeros(maxIt,1);

for it=1:maxIt
    for i=1:nPop
        r1 = rand(1,nVar); r2 = rand(1,nVar);
        V(i,:) = p.w*V(i,:) + p.c1*r1.*(pBest(i,:)-X(i,:)) + p.c2*r2.*(gBest - X(i,:));
        X(i,:) = X(i,:) + V(i,:);
        X(i,:) = min(max(X(i,:),lb),ub);

        Fi = f(X(i,:));
        if Fi < pBestF(i)
            pBestF(i)=Fi; pBest(i,:)=X(i,:);
            if Fi < gBestF, gBestF=Fi; gBest=X(i,:); end
        end
    end
    hist(it)=gBestF;
end
end

% ==============================================================
%                         GA OPTIMIZER
% ==============================================================

function [bestX,bestF,hist] = GA_optimize(f,lb,ub,ga)
lb=lb(:)'; ub=ub(:)';
nVar=numel(lb); nPop=ga.nPop; maxIt=ga.maxIt;

X = rand(nPop,nVar).*repmat(ub-lb,nPop,1) + repmat(lb,nPop,1);
F = zeros(nPop,1);
for i=1:nPop, F(i)=f(X(i,:)); end

hist=zeros(maxIt,1);

for it=1:maxIt
    [~,idx]=sort(F);
    elite = X(idx(1:2),:);

    Xn = elite;
    while size(Xn,1) < nPop
        p1 = X(idx(randi(min(10,nPop))),:);
        p2 = X(idx(randi(min(10,nPop))),:);

        if rand < ga.pc
            a = rand;
            c1 = a*p1 + (1-a)*p2;
            c2 = a*p2 + (1-a)*p1;
        else
            c1 = p1; c2 = p2;
        end

        if rand < ga.pm, c1 = c1 + ga.mutSigma*randn(1,nVar); end
        if rand < ga.pm, c2 = c2 + ga.mutSigma*randn(1,nVar); end

        c1 = min(max(c1,lb),ub);
        c2 = min(max(c2,lb),ub);

        Xn = [Xn; c1; c2]; %#ok<AGROW>
    end

    X = Xn(1:nPop,:);
    for i=1:nPop, F(i)=f(X(i,:)); end

    [bestF,ib]=min(F); bestX=X(ib,:);
    hist(it)=bestF;
end
end
